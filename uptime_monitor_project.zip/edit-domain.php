<?php
include("db.php");
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = intval($_GET['id']);
$result = $conn->query("SELECT * FROM urls WHERE id = $id");
$data = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head><title>Edit URL</title></head>
<link rel="stylesheet" href="style.css">
<body>
<h2>Edit URL</h2>
<form action="update-domain.php" method="POST">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">
    <input type="text" name="url" required value="<?= $data['url'] ?>">
    <button type="submit">Update</button>
</form>
<div style="margin-top: 20px;">
    <a href="index.php"><button>← Back</button></a>
</div>
</body>
</html>
