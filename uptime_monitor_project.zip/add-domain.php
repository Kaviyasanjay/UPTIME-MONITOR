<?php
// add-domain.php
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) grab & validate
    $url     = filter_input(INPUT_POST, 'url', FILTER_VALIDATE_URL);
    $timeout = filter_input(INPUT_POST, 'request_timeout', FILTER_VALIDATE_INT);
    if (!$url || $timeout === false) {
        die("Invalid input.");
    }

    // 2) insert only url + request_timeout
    $stmt = $conn->prepare("
      INSERT INTO urls 
        (url, request_timeout)
      VALUES (?, ?)
    ");
    $stmt->bind_param("si", $url, $timeout);
    $stmt->execute();

    // 3) redirect back
    header("Location: index.php");
    exit;
}
?>
