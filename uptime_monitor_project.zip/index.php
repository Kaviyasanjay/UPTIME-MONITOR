<?php
include("db.php");
$result = $conn->query("SELECT * FROM urls");
?>
<!DOCTYPE html>
<html>
<head> 
  <meta charset="utf-8">
  <title>Uptime Monitor</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    .loader-overlay {
      position: fixed; top:0; left:0;
      width:100%; height:100%;
      background: rgba(255,255,255,0.8);
      z-index: 9999;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .loader {
      border:8px solid #f3f3f3;
      border-top:8px solid #3498db;
      border-radius:50%;
      width:60px; height:60px;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      0%{transform:rotate(0deg);}
      100%{transform:rotate(360deg);}
    }

    /* NEW: error‐state colors */
    .no-error {
      color: #27ae60;
      font-weight: bold;
    }
    .has-error {
      color: #e74c3c;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="loader-overlay" id="loader-overlay">
  <div class="loader"></div>
</div>


<h2>URL Monitor</h2>

<div style="text-align:center; margin-bottom:20px;">
  <a href="new-domain.php">
    <button style="padding:10px 20px; font-weight:bold;">
      ➕ Add or Upload Domains
    </button>
  </a>
</div>

<div class="table-container">

 <table>
    <tr>
      <th>URL</th>
      <th>Status</th>
      <th>Last Checked</th>
      <th>Load Time</th>
      <th>Timeout</th>
      <th>SSL Expiry</th>
      <th>Domain Expiry</th>
      <th>Error</th>
      <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($row['url']) ?></td>
      <td class="<?= $row['status']=='Up'?'status-up':'status-down' ?>">
        <?= $row['status'] ?>
      </td>
      <td><?= $row['last_checked'] ?></td>
      

      <td>
        <i class="fa-solid fa-stopwatch"></i>
        <?php
        if (is_numeric($row['response_time'])) {
          $m = floor($row['response_time']/60);
          $s = str_pad(floor($row['response_time']%60),2,"0",STR_PAD_LEFT);
          echo "{$m}:{$s}";
        } else {
          echo "00:00";
        }
        ?>
      </td>

      

      <td><?= (int)$row['request_timeout'] ?>s</td>
      <td><?= $row['ssl_expiry'] ?></td>
      <td><?= $row['domain_expiry'] ?></td>

      <td class="error-message">
        <?php if ($row['error_message']): ?>
          <span class="has-error">
            <?= htmlspecialchars($row['error_message']) ?>
          </span>
        <?php else: ?>
          <span class="no-error">✅ No Error</span>
        <?php endif; ?>
      </td>

      <td>
        <a href="view-incident.php?id=<?= $row['id'] ?>">View Incident</a>
        <a href="edit-domain.php?id=<?= $row['id'] ?>">✏️</a>
        <a href="delete-domain.php?id=<?= $row['id'] ?>"
           onclick="return confirm('Are you sure to delete this URL?');">🗑️</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<script>
  const overlay = document.getElementById("loader-overlay");
  document.addEventListener("DOMContentLoaded", ()=> overlay.style.display="none");
  setInterval(()=>{
    overlay.style.display="flex";
    location.reload();
  }, 300000); // 5 minutes
</script>

</body>
</html>
