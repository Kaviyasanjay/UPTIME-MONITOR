CREATE TABLE `urls` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT 'Unchecked',
  `last_checked` datetime DEFAULT NULL,
  `response_time` float DEFAULT NULL,
  `ssl_expiry` date DEFAULT NULL,
  `domain_expiry` date DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
);