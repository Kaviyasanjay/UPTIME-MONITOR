<?php
// new-domain.php
include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Domains</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">
    <header>
      <h1>Add or Upload Domains</h1>
    </header>

    <form action="add-domain.php" method="POST" class="form-section">
      <h2>Manual Entry</h2>
      <div class="form-group">
        <label for="url">URL to monitor</label>
        <input type="url" id="url" name="url" placeholder="https://example.com" required>
      </div>
      <div class="form-group">
        <label for="request_timeout">Request Timeout</label>
        <select id="request_timeout" name="request_timeout">
          <option value="5">5 seconds</option>
          <option value="10" selected>10 seconds</option>
          <option value="30">30 seconds</option>
          <option value="60">60 seconds</option>
        </select>
      </div>
      <button type="submit">Add URL</button>
    </form>

    <form action="upload.php" method="POST" enctype="multipart/form-data" class="form-section">
      <h2>Bulk Upload (CSV)</h2>
      <div class="form-group">
        <label for="csv">Choose CSV File</label>
        <input type="file" id="csv" name="csv" accept=".csv" required>
      </div>
      <button type="submit">Upload CSV</button>
      <p style="font-size:12px; color:#777; margin-top:10px;">
        CSV must have a header row with at least <code>url</code>; optional: <code>request_timeout</code>.
      </p>
    </form>

    <div class="back-link">
      <a href="index.php">← Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
