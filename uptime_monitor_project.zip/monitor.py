#!/usr/bin/env python3
import requests
import ssl
import socket
import mysql.connector
import smtplib
from email.mime.text import MIMEText
from datetime import datetime, date
from urllib.parse import urlparse

# === CONFIG ===
db_config = {
    'host':     'localhost',
    'user':     'root',
    'password': '',
    'database': 'uptime_monitor'
}
smtp_config = {
    'server':    'smtp.gmail.com',
    'port':      587,
    'sender':    'kaviyaskaviya419@gmail.com',
    'password':  'uxwd bjya pato lsij',
    'recipients': [
        'kaviyaskaviya419@gmail.com',
        'kaviya@joyinnovations.net',
        'kaviassankar31@gmail.com'
    ]
}
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Accept':      'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

def send_html_email(subject, html):
    msg = MIMEText(html, "html")
    msg['Subject'] = subject
    msg['From']    = smtp_config['sender']
    msg['To']      = ", ".join(smtp_config['recipients'])
    try:
        with smtplib.SMTP(smtp_config['server'], smtp_config['port']) as s:
            s.starttls()
            s.login(smtp_config['sender'], smtp_config['password'])
            s.sendmail(smtp_config['sender'],
                       smtp_config['recipients'],
                       msg.as_string())
    except Exception as e:
        print(f"[ERROR] Unable to send email '{subject}': {e}")

def send_status_alert(domain, url, status, error, ts):
    color      = "#e74c3c" if status == "Down" else "#27ae60"
    state_word = "DOWN"   if status == "Down" else "RECOVERED"
    intro = (
        "<p>We just detected an incident on your monitor. Your service is currently down.</p>"
        if status == "Down"
        else "<p>Great news! Your service has recovered and is now up.</p>"
    )
    follow = (
        "<p>We’ll let you know as soon as it’s back up.</p>"
        if status == "Down"
        else "<p>No further alerts will be sent until the next downtime.</p>"
    )
    html = f"""
    <html>
      <body style="font-family:Arial, sans-serif; line-height:1.4;">
        {intro}
        {follow}
        <h2 style="color:{color}; margin-top:1em;">
          {domain} is <span style="color:{color};">{state_word}</span>
        </h2>
        <p><strong>URL:</strong> <a href="{url}">{url}</a></p>
        <p><strong>Status:</strong> {status}</p>
        <p><strong>Error:</strong> {error or 'No error'}</p>
        <p><strong>Checked at:</strong> {ts}</p>
        <hr>
        <small style="color:#666;">Automated JOY INNOVATIONS uptime monitor</small>
      </body>
    </html>
    """
    send_html_email(f"🔔 {domain} is {state_word}", html)

def send_expiry_reminder(domain, url, what, exp_date, days_left):
    html = f"""
    <html><body style='font-family:Arial;'>
      <h3 style='color:#e67e22;'>{what} Expiry Reminder</h3>
      <p><strong>Domain:</strong> {domain}</p>
      <p><strong>URL:</strong> <a href="{url}">{url}</a></p>
      <p><strong>Expiry date:</strong> {exp_date}</p>
      <p><strong>Days left:</strong> {days_left}</p>
      <hr><small>Automated JOY INNOVATIONS uptime monitor</small>
    </body></html>
    """
    send_html_email(f"⚠️ {what} expires in {days_left}d – {domain}", html)

def check_and_alert():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] Starting full pass…")

    conn = None
    cursor = None
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
          SELECT
            id, url, last_alert_status,
            request_timeout,
            ssl_expiry, domain_expiry,
            ssl_reminder_5_sent, ssl_reminder_3_sent,
            domain_reminder_5_sent, domain_reminder_3_sent
          FROM urls
        """)
        rows = cursor.fetchall()

        for row in rows:
            try:
                url_id  = row['id']
                url     = row['url']
                prev    = row['last_alert_status']
                timeout = int(row['request_timeout'])
                host    = urlparse(url).hostname or ""
                now_ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # HTTP check
                status, error, resp_time = "Down", None, 0.0
                try:
                    t0 = datetime.now()
                    r  = requests.get(url, timeout=timeout, headers=HEADERS)
                    resp_time = (datetime.now() - t0).total_seconds()
                    if r.status_code == 200:
                        status = "Up"
                    else:
                        error = f"HTTP {r.status_code}"
                except Exception as ex:
                    error = str(ex)

                # SSL expiry
                ssl_exp = None
                try:
                    ctx = ssl.create_default_context()
                    with socket.create_connection((host, 443), timeout=5) as sock:
                        with ctx.wrap_socket(sock, server_hostname=host) as ss:
                            cert = ss.getpeercert()
                            ssl_exp = datetime.strptime(
                                cert['notAfter'], "%b %d %H:%M:%S %Y %Z"
                            ).date()
                except:
                    pass

                # Domain expiry via WHOIS
                dom_exp = None
                if host:
                    whois_host = host.lower().lstrip("www.")
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        s.settimeout(10)
                        s.connect(("whois.verisign-grs.com", 43))
                        s.send((whois_host + "\r\n").encode())
                        resp = b""
                        while True:
                            chunk = s.recv(4096)
                            if not chunk: break
                            resp += chunk
                        s.close()
                        text = resp.decode(errors="ignore")
                        for line in text.splitlines():
                            if "Registry Expiry Date:" in line or "Expiration Date:" in line:
                                part = line.split(":", 1)[1].strip()
                                dom_exp = date.fromisoformat(part[:10])
                                break
                    except Exception as e:
                        print(f"[WARN] WHOIS lookup failed for {whois_host}: {e}")

                # Persist
                ssl_str    = ssl_exp.isoformat() if ssl_exp else None
                domain_str = dom_exp.isoformat() if dom_exp else None
                cursor.execute("""
                  UPDATE urls SET
                    status        = %s,
                    last_checked  = %s,
                    response_time = %s,
                    ssl_expiry    = %s,
                    domain_expiry = %s,
                    error_message = %s
                  WHERE id = %s
                """, (status, now_ts, resp_time, ssl_str, domain_str, error, url_id))
                conn.commit()

                # Incident alerts
                if status == "Down" and prev != "Down":
                    cursor.execute("""
                      INSERT INTO incidents
                        (url_id, event_type, code, started_at)
                      VALUES (%s, 'down', %s, %s)
                    """, (url_id, error or f"HTTP {r.status_code}", now_ts))
                    conn.commit()
                    send_status_alert(host, url, status, error, now_ts)
                elif status == "Up" and prev == "Down":
                    cursor.execute("""
                      UPDATE incidents
                         SET event_type='up', resolved_at=%s
                       WHERE url_id=%s
                         AND event_type='down'
                         AND resolved_at IS NULL
                    """, (now_ts, url_id))
                    conn.commit()
                    send_status_alert(host, url, status, "Recovered", now_ts)

                # Expiry reminders
                today = datetime.now().date()
                for what, exp_date, col5, col3 in [
                    ("SSL certificate", ssl_exp,    "ssl_reminder_5_sent",    "ssl_reminder_3_sent"),
                    ("Domain",          dom_exp,    "domain_reminder_5_sent", "domain_reminder_3_sent"),
                ]:
                    if not exp_date:
                        continue
                    days_left = (exp_date - today).days
                    if 1 <= days_left <= 5 and not row[col5]:
                        send_expiry_reminder(host, url, what, exp_date, days_left)
                        cursor.execute(f"UPDATE urls SET {col5}=1 WHERE id=%s", (url_id,))
                        conn.commit()
                    if 1 <= days_left <= 3 and not row[col3]:
                        send_expiry_reminder(host, url, what, exp_date, days_left)
                        cursor.execute(f"UPDATE urls SET {col3}=1 WHERE id=%s", (url_id,))
                        conn.commit()

                # Update last_alert_status
                cursor.execute(
                    "UPDATE urls SET last_alert_status=%s WHERE id=%s",
                    (status, url_id)
                )
                conn.commit()

                print(f"→ Checked {url}: {status} (took {resp_time:.2f}s)")
            except Exception as e:
                print(f"[ERROR] URL ID {row.get('id')} failed: {e}")

    except Exception as e:
        print(f"[ERROR] Main loop failure: {e}")
    finally:
        if cursor: cursor.close()
        if conn:    conn.close()

def main():
    while True:
        check_and_alert()
        # next pass starts immediately, no sleep

if __name__ == "__main__":
    main()
