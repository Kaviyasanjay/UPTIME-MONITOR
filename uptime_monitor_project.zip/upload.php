<?php
include("db.php");
if (isset($_FILES['csv']['tmp_name'])) {
    $file = fopen($_FILES['csv']['tmp_name'], 'r');
    while (($data = fgetcsv($file)) !== FALSE) {
        $url = trim($data[0]);
        if (!empty($url)) {
            $stmt = $conn->prepare("INSERT INTO urls (url, status) VALUES (?, 'Unchecked')");
            $stmt->bind_param("s", $url);
            $stmt->execute();
        }
    }
    fclose($file);
}
header("Location: index.php");
exit();
?>