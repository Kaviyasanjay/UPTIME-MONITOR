<?php
include("db.php");
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id'], $_POST['url'])) {
    $id = intval($_POST['id']);
    $url = trim($_POST['url']);
    $stmt = $conn->prepare("UPDATE urls SET url = ? WHERE id = ?");
    $stmt->bind_param("si", $url, $id);
    $stmt->execute();
}
header("Location: index.php");
exit();
?>
