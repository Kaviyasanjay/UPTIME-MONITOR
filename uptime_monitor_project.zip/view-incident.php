<?php
// view-incident.php
include("db.php");
date_default_timezone_set('Asia/Kolkata');

// 1) Validate & fetch monitor ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid monitor ID.");
}
$url_id = (int)$_GET['id'];

// 2) Fetch this URL’s record
$stmt = $conn->prepare("
  SELECT
    url,
    status,
    last_checked,
    response_time,
    request_timeout,
    ssl_expiry,
    domain_expiry,
    error_message
  FROM urls
  WHERE id = ?
  LIMIT 1
");
$stmt->bind_param("i", $url_id);
$stmt->execute();
$mon = $stmt->get_result()->fetch_assoc();
if (!$mon) {
    die("Monitor not found.");
}

// 3) Load last 10 incidents (use event_type instead of type)
$incStmt = $conn->prepare("
  SELECT
    event_type   AS type,
    code,
    started_at,
    resolved_at
  FROM incidents
  WHERE url_id = ?
  ORDER BY started_at DESC
  LIMIT 10
");
$incStmt->bind_param("i", $url_id);
$incStmt->execute();
$incidents = $incStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// 4) Helpers
function fmtDuration($secs) {
    $h = floor($secs/3600);
    $m = floor(($secs%3600)/60);
    $s = $secs % 60;
    return "{$h}h {$m}m {$s}s";
}
function fmtTime($t) {
    return date("Y-m-d H:i:s", strtotime($t));
}
// Placeholder sparkline (24-bar, random down)
function sparklineBars() {
    $bars = array_fill(0,24,false);
    $bars[5] = $bars[12] = $bars[18] = true;
    return $bars;
}
// Placeholder uptime%
$bars24  = sparklineBars();
$up24pct = "96.1%";
$down24  = "3 incidents, 56m down";
$up7pct  = "96.3%";   $down7  = "19 incidents, 6h 10m down";
$up30pct = "96.8%";   $down30 = "39 incidents, 13h down";

// response‐time placeholders
$respData = array_map(fn($i)=> rand(500,2500), range(1,30));
$avgResp = is_numeric($mon['response_time'])
         ? round($mon['response_time']*1000)." ms" : "--";
$minResp = "-- ms";
$maxResp = "-- ms";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Monitor Details – <?=htmlspecialchars(parse_url($mon['url'],PHP_URL_HOST))?></title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap" rel="stylesheet">
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Inter',sans-serif;background:#1e2330;color:#e0e6f0;}
    a{color:inherit;text-decoration:none}
    .container{max-width:1200px;margin:24px auto;padding:0 16px;}
    .hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;}
    .hdr-left{display:flex;align-items:center;gap:12px;}
    .hdr-left button{background:none;border:none;color:#58a6ff;cursor:pointer;}
    .hdr-left h1{font-size:1.5rem;}
    .hdr-left .sub{font-size:.9rem;color:#9aa3b8;}
    .hdr-right button{margin-left:8px;padding:6px 12px;background:#252a3a;border:none;border-radius:4px;cursor:pointer;}
    .hdr-right button:hover{background:#333a4b;}
    .layout{display:flex;gap:24px;}
    .main{flex:3;}
    .sidebar{flex:1;display:flex;flex-direction:column;gap:16px;}
    .grid2{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-bottom:24px;}
    .card{background:#252a3a;border-radius:8px;padding:16px;}
    .card h2{font-size:.9rem;color:#9aa3b8;margin-bottom:8px;}
    .card p{font-size:1.1rem;margin-bottom:4px;}
    .card .sub{font-size:.8rem;color:#cfd5e0;}
    .status-up p{color:#27ae60;}
    .status-down p{color:#e74c3c;}
    .spark{display:flex;align-items:flex-end;gap:4px;height:40px;margin:8px 0;}
    .spark .bar{flex:1;width:8px;border-radius:4px;background:#27ae60;}
    .spark .bar.down{background:#e74c3c;}
    .pct{font-size:.9rem;text-align:right;}
    .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:24px;}
    .stat{background:#252a3a;border-radius:8px;padding:16px;}
    .stat h3{font-size:.9rem;color:#9aa3b8;margin-bottom:8px;}
    .stat .num{font-size:1.3rem;color:#ffa500;margin-bottom:4px;}
    .stat .desc{font-size:.8rem;color:#cfd5e0;}
    .chart-card{background:#252a3a;border-radius:8px;padding:16px;margin-bottom:24px;}
    .chart-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;}
    .chart-header h2{font-size:.9rem;color:#9aa3b8;}
    .chart-header button{padding:6px 12px;background:#252a3a;border:none;border-radius:4px;cursor:pointer;}
    canvas{width:100%!important;height:200px!important;border-radius:4px;}
    .chart-stats{display:flex;justify-content:space-around;margin-top:16px;}
    .chart-stats .item{text-align:center;}
    .chart-stats .item .val{font-size:1rem;}
    .chart-stats .item .lbl{font-size:.8rem;color:#cfd5e0;}
    .tbl-card{background:#252a3a;border-radius:8px;padding:16px;margin-bottom:24px;}
    .tbl-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;}
    .tbl-header h2{font-size:.9rem;color:#9aa3b8;}
    .tbl-header button{padding:6px 12px;background:#3a3f51;border:none;border-radius:4px;cursor:pointer;}
    table{width:100%;border-collapse:collapse;}
    th,td{padding:8px;font-size:.85rem;border-bottom:1px solid #333740;}
    th{color:#9aa3b8;text-align:left;}
    tr:hover{background:#333a4b;}
    .tc-down{color:#e74c3c;}
    .tc-up{color:#27ae60;}
    .tc-code{font-family:monospace;padding:2px 4px;border-radius:4px;color:#e74c3c;}
    .sb-card{background:#252a3a;border-radius:8px;padding:16px;}
    .sb-card h3{font-size:.9rem;color:#9aa3b8;margin-bottom:8px;}
    .sb-card .val{font-size:1rem;}
    .sb-card button{margin-top:8px;padding:6px 12px;background:#252a3a;border:none;border-radius:4px;cursor:pointer;}
  </style>
</head>
<body>
  <div class="container">

    <!-- header -->
    <div class="hdr">
      <div class="hdr-left">
        <button onclick="location.href='index.php'">← Monitoring</button>
        <h1><?=htmlspecialchars(parse_url($mon['url'],PHP_URL_HOST))?>/</h1>
        <div class="sub">
          HTTP/S monitor for
          <a href="<?=htmlspecialchars($mon['url'])?>" target="_blank"><?=htmlspecialchars($mon['url'])?></a>
        </div>
      </div>
      <div class="hdr-right">
        <button>Test Notification</button>
        <button>Pause</button>
        <button>Edit</button>
      </div>
    </div>

    <div class="layout">
      <div class="main">

        <!-- top‐row cards -->
        <div class="grid2">
          <div class="card status-<?= strtolower($mon['status']) ?>">
            <h2>Current status</h2>
            <p><?= $mon['status'] ?></p>
            <div class="sub">Up for <?= fmtDuration(time() - strtotime($mon['last_checked'])) ?></div>
          </div>

          <div class="card">
            <h2>Last check</h2>
            <p><?= fmtTime($mon['last_checked']) ?></p>
            <div class="sub">Timeout: <?= intval($mon['request_timeout']) ?>s</div>
          </div>

          <div class="card">
            <h2>Last 24 hours</h2>
            <div class="spark">
              <?php foreach($bars24 as $down): ?>
                <div class="bar <?= $down ? 'down':'' ?>"></div>
              <?php endforeach; ?>
            </div>
            <div class="pct"><?= $up24pct ?> · <?= $down24 ?></div>
          </div>
        </div>

        <!-- 7/30/365 stats -->
        <div class="grid3">
          <div class="stat">
            <h3>Last 7 days</h3>
            <div class="num"><?= $up7pct ?></div>
            <div class="desc"><?= $down7 ?></div>
          </div>
          <div class="stat">
            <h3>Last 30 days</h3>
            <div class="num"><?= $up30pct ?></div>
            <div class="desc"><?= $down30 ?></div>
          </div>
          <div class="stat">
            <h3>Last 365 days</h3>
            <div class="num">––.–%</div>
            <div class="desc"><a href="#" style="color:#58a6ff">Unlock with paid plans</a></div>
          </div>
        </div>

        <!-- response‐time graph -->
        <div class="chart-card">
          <div class="chart-header">
            <h2>Response time</h2>
            <button><i class="fa fa-lock"></i> Setup alerts</button>
          </div>
          <canvas id="respChart"></canvas>
          <div class="chart-stats">
            <div class="item"><div class="val"><?= $avgResp ?></div><div class="lbl"><i class="fa fa-sync-alt"></i> Average</div></div>
            <div class="item"><div class="val"><?= $minResp ?></div><div class="lbl"><i class="fa fa-arrow-down"></i> Minimum</div></div>
            <div class="item"><div class="val"><?= $maxResp ?></div><div class="lbl"><i class="fa fa-arrow-up"></i> Maximum</div></div>
          </div>
        </div>

        <!-- latest incidents -->
        <div class="tbl-card">
          <div class="tbl-header">
            <h2>Latest incidents</h2>
            <button>Export logs</button>
          </div>
          <table>
            <tr><th>Status</th><th>Root Cause</th><th>Started</th><th>Duration</th></tr>
            <?php foreach($incidents as $inc):
                $dur = $inc['resolved_at']
                     ? strtotime($inc['resolved_at']) - strtotime($inc['started_at'])
                     : time() - strtotime($inc['started_at']);
            ?>
            <tr>
              <td class="tc-<?= strtolower($inc['type']) ?>"><?= ucfirst($inc['type']) ?></td>
              <td class="tc-code"><?= htmlspecialchars($inc['code']) ?></td>
              <td><?= date("M j, Y H:i", strtotime($inc['started_at'])) ?></td>
              <td><?= fmtDuration($dur) ?></td>
            </tr>
            <?php endforeach; ?>
          </table>
        </div>

      </div>

      <!-- sidebar -->
      <div class="sidebar">
        <div class="sb-card">
          <h3>Domain valid until</h3>
          <div class="val"><?= $mon['domain_expiry'] ?: '—' ?></div>
          <h3>SSL certificate valid until</h3>
          <div class="val"><?= $mon['ssl_expiry'] ?: '—' ?></div>
        </div>
        <div class="sb-card">
          <h3>Next maintenance</h3>
          <div class="val">No maintenance planned.</div>
          <button>Set up maintenance</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
  <script>
    new Chart(document.getElementById('respChart'), {
      type: 'line',
      data: {
        labels: Array(30).fill(''),
        datasets:[{
          data: <?= json_encode($respData) ?>,
          borderColor:'#27ae60',background:'transparent',
          tension:.4,pointRadius:0,borderWidth:2
        }]
      },
      options:{
        scales:{ x:{display:false}, y:{display:false} },
        plugins:{ legend:{display:false}, tooltip:{enabled:false} }
      }
    });
  </script>
</body>
</html>
